/*=====================================================================
  Provinent Scripture Study – highlights.js
  Verse highlighting and color management
=====================================================================*/

import { escapeHTML } from '../main.js';
import { loadSelectedChapter, syncBookChapterSelectors } from './navigation.js';
import { updateDisplayRef } from './passage.js';
import { BOOK_ORDER, saveToStorage, state, updateURL } from './state.js';

/* ====================================================================
   CONSTANTS
==================================================================== */

const HIGHLIGHT_COLORS = [
    'yellow', 'green', 'blue', 'pink', 'orange', 'purple'
];

/* ====================================================================
   HIGHLIGHTING FUNCTIONS
==================================================================== */

/**
 * Show color picker at mouse/touch position
 * @param {Event} ev - Mouse or touch event
 * @param {HTMLElement} verseEl - Verse element
 */
export function showColorPicker(ev, verseEl) {
    try {
        const picker = document.getElementById('colorPicker');
        if (!picker) return;
        
        state.currentVerse = verseEl;
        
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        
        const pickerWidth = 200;
        const pickerHeight = 50;
        
        const clientX = ev.clientX || (ev.touches?.[0]?.clientX) || 0;
        const clientY = ev.clientY || (ev.touches?.[0]?.clientY) || 0;
        
        let adjustedX = Math.max(10, clientX);
        let adjustedY = Math.max(10, clientY);
        
        if (clientX + pickerWidth > viewportWidth) {
            adjustedX = viewportWidth - pickerWidth - 10;
        }
        
        if (clientY + pickerHeight > viewportHeight) {
            adjustedY = viewportHeight - pickerHeight - 10;
        }
        
        picker.style.left = adjustedX + 'px';
        picker.style.top = adjustedY + 'px';
        picker.classList.add('active');
        
        if (ev.preventDefault) ev.preventDefault();
        if (ev.stopPropagation) ev.stopPropagation();
        
    } catch (error) {
        console.error('Error showing color picker:', error);
    }
}

/**
 * Apply highlight color to selected verse
 * @param {string} color - Color to apply ('none' to remove)
 */
export function applyHighlight(color) {
    try {
        if (!state.currentVerse) return;
        
        const verseRef = state.currentVerse.dataset.verse;
        if (!verseRef) return;
        
        // Remove all highlight classes
        state.currentVerse.classList.remove(...HIGHLIGHT_COLORS.map(col => `highlight-${col}`));
        
        if (color !== 'none') {
            state.currentVerse.classList.add(`highlight-${color}`);
            state.highlights[verseRef] = color;
            
            // Update timestamp
            if (!state._syncMeta.highlights[verseRef]) {
                state._syncMeta.highlights[verseRef] = {};
            }
            state._syncMeta.highlights[verseRef].ts = Date.now();
        } else {
            // DELETION: Keep metadata but mark as deleted
            delete state.highlights[verseRef];
            
            if (!state._syncMeta.highlights[verseRef]) {
                state._syncMeta.highlights[verseRef] = {};
            }
            state._syncMeta.highlights[verseRef].deleted = true;
            state._syncMeta.highlights[verseRef].ts = Date.now();
        }
        
        saveToStorage();
        
        const picker = document.getElementById('colorPicker');
        if (picker) picker.classList.remove('active');
        
    } catch (error) {
        console.error('Error applying highlight:', error);
    }
}

/**
 * Clear all verse highlights with confirmation
 */
export function clearHighlights() {
    try {
        if (!confirm('Are you sure you want to delete ALL highlights? This cannot be undone.')) {
            return;
        }
        
        // Mark ALL existing highlights as deleted with timestamps
        const now = Date.now();
        Object.keys(state.highlights).forEach(ref => {
            if (!state._syncMeta.highlights) state._syncMeta.highlights = {};
            state._syncMeta.highlights[ref] = {
                deleted: true,
                ts: now
            };
        });
        
        // Clear the highlights object
        state.highlights = {};
        
        // Remove highlight classes from all verses
        document.querySelectorAll('.verse').forEach(verse => {
            verse.classList.remove(...HIGHLIGHT_COLORS.map(col => `highlight-${col}`));
        });
        
        saveToStorage();
        
        // Refresh highlights modal if open
        const modal = document.getElementById('highlightsModal');
        if (modal?.classList.contains('active')) {
            renderHighlights('all', '');
        }
        
        console.log('[Highlights] Cleared all highlights with sync tombstones');
        
    } catch (error) {
        console.error('Error clearing highlights:', error);
    }
}

/* ====================================================================
   MODAL FUNCTIONS
==================================================================== */

/**
 * Open highlights modal
 */
export function showHighlightsModal() {
    try {
        const overlay = document.getElementById('highlightsOverlay');
        const modal = document.getElementById('highlightsModal');
        const searchInput = document.getElementById('highlightsSearch');
        
        if (!overlay || !modal) return;
        
        overlay.classList.add('active');
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        // Reset search
        if (searchInput) {
            searchInput.value = '';
        }
        
        // Reset filter buttons
        const filterButtons = document.querySelectorAll('.highlight-filter-btn');
        filterButtons.forEach(btn => btn.classList.remove('active'));
        
        const allButton = document.querySelector('.highlight-filter-btn[data-color="all"]');
        if (allButton) {
            allButton.classList.add('active');
        }
        
        renderHighlights('all', '');
        setupHighlightsSearch();
        
    } catch (error) {
        console.error('Error opening highlights modal:', error);
    }
}

/**
 * Close highlights modal
 */
export function closeHighlightsModal() {
    try {
        const overlay = document.getElementById('highlightsOverlay');
        const modal = document.getElementById('highlightsModal');
        
        if (!overlay || !modal) return;
        
        overlay.classList.remove('active');
        modal.classList.remove('active');
        document.body.style.overflow = '';
        
    } catch (error) {
        console.error('Error closing highlights modal:', error);
    }
}

/**
 * Handle search input changes (named for removeEventListener)
 */
function handleSearchInput(e) {
    try {
        const searchTerm = e.target.value.toLowerCase().trim();
        const activeFilter = document.querySelector('.highlight-filter-btn.active')?.dataset.color || 'all';
        renderHighlights(activeFilter, searchTerm);
    } catch (error) {
        console.error('Error handling search input:', error);
    }
}

/**
 * Handle filter button clicks (named for removeEventListener)
 */
function handleFilterClick(e) {
    try {
        const btn = e.currentTarget;
        const color = btn.dataset.color;
        const searchInput = document.getElementById('highlightsSearch');
        const searchTerm = (searchInput?.value || '').toLowerCase().trim();
        renderHighlights(color, searchTerm);
        
        // Update active state
        document.querySelectorAll('.highlight-filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
    } catch (error) {
        console.error('Error handling filter click:', error);
    }
}

/**
 * Handle clear search button click (named for removeEventListener)
 */
function handleClearSearch() {
    try {
        const searchInput = document.getElementById('highlightsSearch');
        if (!searchInput) return;
        
        searchInput.value = '';
        const activeFilter = document.querySelector('.highlight-filter-btn.active')?.dataset.color || 'all';
        renderHighlights(activeFilter, '');
    } catch (error) {
        console.error('Error clearing search:', error);
    }
}

/**
 * Set up search functionality for highlights (prevents duplicate listeners)
 */
function setupHighlightsSearch() {
    try {
        const searchInput = document.getElementById('highlightsSearch');
        const clearSearchBtn = document.getElementById('clearSearch');
        
        // Remove existing listeners to prevent duplicates
        if (searchInput) {
            searchInput.removeEventListener('input', handleSearchInput);
            searchInput.addEventListener('input', handleSearchInput);
        }
        
        if (clearSearchBtn) {
            clearSearchBtn.removeEventListener('click', handleClearSearch);
            clearSearchBtn.addEventListener('click', handleClearSearch);
        }

        // Remove existing filter listeners, then add new ones
        document.querySelectorAll('.highlight-filter-btn').forEach(btn => {
            btn.removeEventListener('click', handleFilterClick);
            btn.addEventListener('click', handleFilterClick);
        });        
    } catch (error) {
        console.error('Error setting up highlights search:', error);
    }
}

/* ====================================================================
   HIGHLIGHTS RENDERING
==================================================================== */

/**
 * Get a validated cache object once per render cycle
 * @param {boolean} forceClearOnInvalid - If true, clear storage on validation failure (for manual calls)
 * @returns {Object|null} - Valid cache or null if invalid
 */
function getValidatedCache(forceClearOnInvalid = false) {
    try {
        const rawData = localStorage.getItem('cachedVerses');
        if (!rawData) {
            return {};
        }

        let cachedVerses;
        try {
            cachedVerses = JSON.parse(rawData);
        } catch (parseError) {
            console.error('Invalid JSON in cachedVerses:', parseError);
            if (forceClearOnInvalid) {
                localStorage.removeItem('cachedVerses');
            }
            return null;
        }

        // Validate: plain object, no arrays/funks
        if (cachedVerses === null || typeof cachedVerses !== 'object' || Array.isArray(cachedVerses)) {
            console.error('cachedVerses is not a valid object');
            if (forceClearOnInvalid) {
                localStorage.removeItem('cachedVerses');
            }
            return null;
        }

        // Quick scan: all entries must have string keys/values
        for (const [key, value] of Object.entries(cachedVerses)) {
            if (typeof key !== 'string' || typeof value !== 'string') {
                console.error('Invalid entry in cachedVerses at key:', key);
                if (forceClearOnInvalid) {
                    localStorage.removeItem('cachedVerses');
                }
                return null;
            }
            // Sanitize each value early
            const sanitized = value.trim().replace(/[\x00-\x1F\x7F]/g, '');
            if (sanitized.length === 0 || sanitized.length > 10000) {
                console.warn('Invalid verse length at', key, '; skipping');
                delete cachedVerses[key];
            } else {
                cachedVerses[key] = sanitized;
            }
        }

        // If many invalids, optionally clear (but we clean per-entry here)
        return cachedVerses;
    } catch (error) {
        console.error('Error validating cache:', error);
        return null;
    }
}

/**
 * Render highlights list in modal
 * @param {string} filterColor - Color filter
 * @param {string} searchTerm - Search term (already lowercased/trimmed)
 */
export function renderHighlights(filterColor = 'all', searchTerm = '') {
    try {
        const highlightsList = document.getElementById('highlightsList');
        if (!highlightsList) return;
        
        const highlights = state.highlights || {};
        
        if (Object.keys(highlights).length === 0) {
            highlightsList.innerHTML = '<div class="no-highlights">No verses have been highlighted yet</div>';
            return;
        }
        
        // Batch-validate cache once for efficiency
        const validatedCache = getValidatedCache(false);
        if (validatedCache === null) {
            // If fully invalid, show warning but don't render empties
            highlightsList.innerHTML = '<div class="warning">Cached verse data is invalid. Visit verses to refresh highlights display.</div>';
            return;
        }
        
        const sortedReferences = sortHighlightReferences(highlights);
        const filteredReferences = filterHighlightReferences(sortedReferences, filterColor, searchTerm, validatedCache);
        
        let html = '';
        
        if (filteredReferences.length === 0) {
            const noResultsMsg = searchTerm 
                ? `No highlights found matching "${searchTerm}"`
                : 'No highlights match the selected filter';
            html = `<div class="no-results">${noResultsMsg}</div>`;
        } else {
            html = generateHighlightItemsHTML(filteredReferences, searchTerm, validatedCache);
        }
        
        highlightsList.innerHTML = html;
        setupHighlightItemClickHandlers();
        
    } catch (error) {
        console.error('Error rendering highlights:', error);
        const highlightsList = document.getElementById('highlightsList');
        if (highlightsList) {
            highlightsList.innerHTML = '<div class="error">Error loading highlights</div>';
        }
    }
}

/**
 * Sort highlight references by book, chapter, verse
 * @param {Object} highlights - Highlights object
 * @returns {Array} - Sorted references
 */
function sortHighlightReferences(highlights) {
    return Object.keys(highlights)
        .map(reference => {
            const match = reference.match(/^(.+?)\s+(\d+):(\d+)$/);
            if (!match) return null;
            
            const [, bookName, chapter, verse] = match;
            const color = highlights[reference];
            
            // Parse book name for sorting
            const bookParts = bookName.split(' ');
            let bookNumber = '';
            let baseBookName = bookName;
            
            if (bookParts.length > 1 && /^\d+$/.test(bookParts[0])) {
                bookNumber = bookParts[0];
                baseBookName = bookParts.slice(1).join(' ');
            }
            
            const bookIndex = BOOK_ORDER.findIndex(book => {
                const orderParts = book.split(' ');
                let orderNumber = '';
                let orderBaseName = book;
                
                if (orderParts.length > 1 && /^\d+$/.test(orderParts[0])) {
                    orderNumber = orderParts[0];
                    orderBaseName = orderParts.slice(1).join(' ');
                }
                
                return orderBaseName.toLowerCase() === baseBookName.toLowerCase() && 
                       orderNumber === bookNumber;
            });
            
            if (bookIndex === -1) return null;
            
            return {
                reference,
                bookName,
                bookIndex,
                chapter: parseInt(chapter),
                verse: parseInt(verse),
                color
            };
        })
        .filter(ref => ref !== null)
        .sort((a, b) => {
            if (a.bookIndex !== b.bookIndex) return a.bookIndex - b.bookIndex;
            if (a.chapter !== b.chapter) return a.chapter - b.chapter;
            return a.verse - b.verse;
        });
}

/**
 * Filter highlight references by color and search term
 * @param {Array} references - Sorted references
 * @param {string} filterColor - Color filter
 * @param {string} searchTerm - Search term (lowercased)
 * @param {Object} validatedCache - Pre-validated cache object
 * @returns {Array} - Filtered references
 */
function filterHighlightReferences(references, filterColor, searchTerm, validatedCache) {
    return references.filter(ref => {
        // Filter by color
        if (filterColor !== 'all' && ref.color !== filterColor) {
            return false;
        }
        
        // Filter by search term using cache (case-insensitive)
        if (searchTerm) {
            const verseText = validatedCache[ref.reference] || '';
            if (!verseText.toLowerCase().includes(searchTerm) && 
                !ref.reference.toLowerCase().includes(searchTerm)) {
                return false;
            }
        }
        
        return true;
    });
}

/**
 * Generate HTML for highlight items
 * @param {Array} references - Filtered references
 * @param {string} searchTerm - Search term for highlighting (lowercased, but regex uses 'gi')
 * @param {Object} validatedCache - Pre-validated cache object
 * @returns {string} - HTML string
 */
function generateHighlightItemsHTML(references, searchTerm, validatedCache) {
    return references.map(ref => {
        const verseText = validatedCache[ref.reference] || 'Text not cached, visit to refresh';
        let displayText = verseText;
        
        // Highlight search terms (preserves original case via 'gi' regex)
        if (searchTerm) {
            const regex = new RegExp(`(${escapeRegExp(searchTerm)})`, 'gi');
            displayText = verseText.replace(regex, '<mark>$1</mark>');
        }
        
        return `
            <div class="highlight-item ${ref.color}" 
                 data-reference="${escapeHTML(ref.reference)}" 
                 data-color="${escapeHTML(ref.color)}">
                <div class="highlight-ref">${escapeHTML(ref.reference)}</div>
                <div class="highlight-text">${displayText}</div>
            </div>
        `;
    }).join('');
}

/**
 * Set up click handlers for highlight items
 */
function setupHighlightItemClickHandlers() {
    document.querySelectorAll('.highlight-item').forEach(item => {
        item.addEventListener('click', () => {
            const reference = item.dataset.reference;
            navigateToHighlightedVerse(reference);
            closeHighlightsModal();
        });
    });
}

/**
 * Escape regex special characters
 * @param {string} string - String to escape
 * @returns {string} - Escaped string
 */
function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/* ====================================================================
   NAVIGATION FUNCTIONS
==================================================================== */

/**
 * Scroll to specific verse number
 * @param {number} verseNumber - Verse number to scroll to
 */
export function scrollToVerse(verseNumber) {
    try {
        updateDisplayRef(state.settings.manualBook, state.settings.manualChapter);
        syncBookChapterSelectors();
        
        const verseElement = document.querySelector(`.verse[data-verse-number="${verseNumber}"]`);
        if (verseElement) {
            verseElement.scrollIntoView({ 
                behavior: 'smooth', 
                block: 'center' 
            });
            
            // Highlight temporarily
            verseElement.style.backgroundColor = 'var(--verse-hover)';
            setTimeout(() => {
                verseElement.style.backgroundColor = '';
            }, 1000);
        }
    } catch (error) {
        console.error('Error scrolling to verse:', error);
    }
}

/**
 * Retrieve verse text from localStorage cache with validation
 * @param {string} reference - Verse reference
 * @param {boolean} forceClearOnInvalid - If true, clear on full invalid (rare manual use)
 * @returns {string|null} - Valid verse text or null
 */
export function getVerseTextFromStorage(reference, forceClearOnInvalid = false) {
    // For non-batch calls, fall back to single validation (but prefer batch via render)
    const cachedVerses = getValidatedCache(forceClearOnInvalid);
    if (!cachedVerses || !(reference in cachedVerses)) {
        return null;
    }
    return cachedVerses[reference];
}

/**
 * Navigate to highlighted verse
 * @param {string} reference - Full verse reference
 */
function navigateToHighlightedVerse(reference) {
    try {
        const match = reference.match(/^(.+?)\s+(\d+):(\d+)$/);
        if (!match) return;
        
        const [, book, chapter, verse] = match;
        state.settings.manualBook = book;
        state.settings.manualChapter = parseInt(chapter);
        
        const translation = state.settings.bibleTranslation;
        
        updateURL(translation, book, chapter, 'push');
        
        loadSelectedChapter(book, chapter);
        
        setTimeout(() => scrollToVerse(parseInt(verse)), 500);
    } catch (error) {
        console.error('Error navigating to highlighted verse:', error);
    }
}
